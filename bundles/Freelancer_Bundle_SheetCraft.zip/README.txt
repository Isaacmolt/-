SheetCraft AI — Freelancer Bundle

Built for freelancers — income tracking, budgeting, and project management in one package.

Included Templates:
  - Freelancer_Income_Tracker_SheetCraft.xlsx
  - 503020_Budget_Template_SheetCraft.xlsx
  - Project_Management_Board_SheetCraft.xlsx

How to Use:
1. Open each .xlsx file in Google Sheets (File → Import → Upload)
2. Or open directly in Microsoft Excel
3. Each template includes an Instructions tab

Thank you for your purchase!
For support, message us on Etsy.
