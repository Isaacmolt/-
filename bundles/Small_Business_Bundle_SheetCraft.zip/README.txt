SheetCraft AI — Small Business Bundle

Everything a small business needs — P&L statements, inventory management, and client CRM.

Included Templates:
  - Small_Business_PL_SheetCraft.xlsx
  - Inventory_Manager_SheetCraft.xlsx
  - Client_CRM_Tracker_SheetCraft.xlsx

How to Use:
1. Open each .xlsx file in Google Sheets (File → Import → Upload)
2. Or open directly in Microsoft Excel
3. Each template includes an Instructions tab

Thank you for your purchase!
For support, message us on Etsy.
